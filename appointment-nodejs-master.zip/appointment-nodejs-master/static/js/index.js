// const socket = io.connect('http://localhost:3000')
//         let name = "nik"
//         // socket.emit(`user-joined`, name)
//         // socket.on('connected', (name)=>{
//         //     console.log(name)
//         // })
//         // socket.emit('noti')
//         socket.on('1', (name)=>{
//             console.log('ye ho gya')
//             console.log(name)
//         })